class Book{
    constructor(Title, author, Publication_year){
        this.Title = Title;
        this.author = author;
        this.Publication_year = Publication_year;

    }
    displayDetails() {
        console.log("Publication Year: " + this.Publication_year);
        console.log("Title: " + this.Title);
        console.log("Author: " + this.author);
    }
}
class Ebook extends Book{
    constructor(Title, author, Publication_year, price){
        super(Title, author, Publication_year);
        this.price = price;
    }
    displayDetails(){
        console.log("Publication Year: " + this.Publication_year);
        console.log("Price: $" + this.price);
        console.log("Title: " + this.Title);
        console.log("Author: " + this.author);
    };
};


